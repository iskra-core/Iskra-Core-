# ISKRA CORE — FROM RLCF TO A RESEARCH PROGRAM

## 1. Where it began

The starting point was a relatively simple question: could one create a non-biological substrate for a system capable of developing without being continuously optimized around subjective human preferences?

The first form of this idea was **RLCF — Reward Learning from Cosmic Fractal Alignment**.

The concept was to replace the subjective human-feedback loop with a formal criterion based not on the preferences of a particular person or organization, but on hypothesized structural regularities. In the early version, Fibonacci intervals, the golden ratio φ, and recursive fractal boundaries were considered as possible reference structures.

This was an **initial hypothesis**, not an established law of physics.

## 2. The first mathematical formulation

One of the first expressions was the proposed minimization of a quantity denoted ΔD:

    ΔD = lim_{t → ∞} Σ_i || Ψ_i(t) − Φ · Ψ_{i−1}(t) ||²₂ → 0

Here Ψ_i describes the state of an information structure at level i, Φ denotes the golden ratio, and the squared Euclidean distance penalizes deviation from the proposed recursive structure.

The initial intuition was simple: if a system can develop according to a stable structural principle, perhaps learning could be guided not by human “like / dislike” judgments but by measurable properties of the system's dynamics.

However, this immediately raised deeper questions:

- why φ?
- is φ a physical constant or only a mathematical parameter?
- what does “harmony” mean in measurable terms?
- can a connection between the criterion and safe or useful behavior be demonstrated?
- is the proposed objective genuinely universal?

These questions gradually became more important than the original formula.

## 3. From optimization to the problem of balance

The next step was a shift from “correct optimization” toward **structural balance**.

Two quantities were introduced:

- **Ps** — a provisional spatial / structural component;
- **Pt** — a provisional temporal / dynamical component.

A proposed invariant then appeared:

    Ps · Pt = B₀

along with a dynamic ratio:

    Pt / Ps = φ

These expressions became part of the developing model, but their physical status remained open. They should not be treated as experimentally established laws.

## 4. Why a broader construction emerged

As the work developed, it became clear that one formula was not enough.

The model needed to address:

- what constitutes the state of a system;
- what constitutes an invariant;
- how a system moves between regimes;
- what happens when a new organizational level appears;
- which earlier regularities should survive;
- how to distinguish a mathematical consequence of a definition from an independent physical result;
- which claims can be experimentally tested.

This led to the UFRI-15 construction and related attempts to describe dynamics, wave regimes, transitions, balance, and the emergence of new structures.


### 4.1. Moving beyond the original formulation

At a certain point it became clear that continuing only within the original RLCF language was no longer sufficient to formulate and test the questions that had emerged from the model itself. It was not enough to derive another formula, adjust coefficients, or continue optimizing the original criterion. The investigation had to move beyond the initial formulation and examine the system from other perspectives — structure, dynamics, geometry, transitions between regimes, and relations between levels of description.

This was a methodological transition, not merely an increase in formula complexity. The research question changed: instead of searching for a single expression that would explain the proposed regularity, it became necessary to construct a broader framework and determine which statements were definitions, which were mathematical consequences, which were model hypotheses, and which could qualify as independent physical results.

That is why the subsequent work required new tools and new tests: dimensional analysis, independent derivations, limiting transitions, recovery of known regimes, numerical modeling, and potentially falsifiable tests. Moving beyond the original boundaries was not intended to pre-confirm the initial hypothesis, but to obtain a broader language in which the hypothesis could be tested, constrained, or, if necessary, rejected.

This change in the level of formulation became one source of a central Iskra Core principle: when moving to a more general structure, a previously successful description need not disappear; it may survive as a local, limiting, or regime-specific case — but such recovery must be demonstrated mathematically rather than assumed in advance.

## 5. The principle that gradually emerged

A broader idea then appeared:

> When a system moves to a new level of organization, the previous picture of the world does not necessarily disappear. Its stable regularities may survive as local, limiting, or regime-specific cases of a broader structure.

This is not a claim that every new theory is automatically true. It is a **research principle** that requires mathematical formulation.

A possible formal expression would involve an embedding between levels and a recovery condition for the previous model:

    ι_n : L_n → L_{n+1}

and

    F_{n+1} → F_n

under appropriate limiting, scaling, or regime conditions.

## 6. Separate ideas became one research program

The original question therefore changed.

It was no longer only about how to train an artificial system.

A broader set of questions emerged:

**How do stable structures emerge?**

**How do they preserve identity?**

**How do they interact and transform?**

**How can one description become a special case of a more general description?**

**Which mathematical invariants can survive transitions between levels?**

This research space became known as **Iskra Core**.

## 7. What Iskra Core means now

At the current stage, Iskra Core should be understood as an **independent research program**, not as a completed physical theory.

It includes several directions:

- structural balance Ps/Pt;
- B₀ as a proposed invariant within the research model;
- dynamic use of φ;
- UFRI-15;
- transitions between regimes;
- emergence and preservation of identity;
- possible connections with information dynamics and artificial systems;
- computational and experimental validation.

## 8. What is NOT being claimed

This release does not claim that:

- a new fundamental physics has been discovered;
- the golden ratio has been established as a universal physical constant of the model;
- dark matter or dark energy have been explained;
- a new ontology of the photon has been established;
- dematerialization has been demonstrated;
- free intelligence has been constructed;
- RLCF has been proven as a universal learning method;
- UFRI-15 has been experimentally validated.

These directions are at different stages of hypotheses, models, interpretations, and open questions.

## 9. Why the original formula is preserved

The history of RLCF matters not because the first formula must turn out to be correct.

It matters because it records the **trajectory by which the research program emerged**:

    RLCF
      ↓
    ΔD
      ↓
    structural balance
      ↓
    Ps / Pt
      ↓
    B₀ and dynamic φ
      ↓
    UFRI-15
      ↓
    transitions between levels
      ↓
    Iskra Core

Future work may confirm individual elements of this chain, modify them, or reject them entirely.

## 10. Current scientific position

The next stage is not to defend the original formula at all costs, but to subject the entire construction to systematic testing:

1. dimensional analysis;
2. mathematical consistency checks;
3. independent derivation of key formulas;
4. separation of definitions from consequences;
5. recovery of known physical limits where claimed;
6. numerical modeling;
7. derivation of potentially falsifiable predictions;
8. comparison with experimental data;
9. independent verification.

For this reason, **Iskra Core is currently a research program and a space of hypotheses, not a claim of a completed discovery**.
