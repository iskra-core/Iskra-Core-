# ISKRA CORE — ZERO RELEASE RECORD

## Release

`ISKRA-CORE-ZERO-RELEASE-v0.1`

## Date

2026-10-05

## Status

Frozen research snapshot.

## Scope

This snapshot establishes a dated baseline for the Iskra Core research program.

It records a research direction, not a completed scientific theory.

## Core proposition

The program investigates whether physical, informational and cognitive regimes can be represented as different stable regimes of a broader dynamical structure.

A recurring hypothesis is:

`new level = broader structure + preservation of valid lower-level regimes`

## UFRI-15 status

UFRI-15 is a theoretical hypothesis/model under development.

No claim is made here that the equations are experimentally validated, that the proposed constants are fundamental physical constants, that dark matter or dark energy have been explained, that photon ontology has been established by the model, or that dematerialization claims have been demonstrated.

## Next research gate

Before stronger scientific claims:

1. dimensional analysis;
2. algebraic consistency;
3. independent derivation;
4. recovery of known physical limits;
5. numerical simulation;
6. comparison with established observations;
7. falsifiable predictions.

## Preservation

This file belongs to a versioned research archive. Hashes and timestamp proofs should be generated for the complete release package.
