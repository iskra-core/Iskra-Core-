# ISKRA CORE — Zero Release v0.1

**Status:** research hypothesis / exploratory theoretical program  
**Date:** 2026-10-05  
**Human initiator:** Iskra Core  
**AI role:** analytical, mathematical, modeling and verification assistant

## Purpose

This release records the initial research position of the Iskra Core program and preserves a stable reference point for subsequent development.

The central research intuition is that a broader theory may contain previous laws as local, limiting or regime-specific descriptions rather than simply replacing them.

## Current research directions

1. Space/time potential framework: `Ps`, `Pt`, `B0`.
2. Dynamic balance and the proposed role of `φ`.
3. UFRI-15: a proposed impulse-unfolding framework with resistance/inertia terms.
4. Photon as a proposed transition/boundary regime.
5. Emergence of stable structures through threshold, tracking, formation and identity.
6. AI-assisted mathematical and computational experimentation.

## Epistemic boundary

This release distinguishes source ideas, mathematical derivations, model assumptions, physical hypotheses, experimentally testable predictions and philosophical interpretations.

No item is presented as proof of a new physical law unless independently demonstrated.
