# ISKRA CORE — Independent Research Group Charter v0.1

## 1. Nature

Iskra Core is an independent research initiative. At this stage it is a research identity and project structure, not a claim that a particular legal entity has been incorporated.

## 2. Human responsibility

The human initiator is the author, researcher and responsible decision-maker.

## 3. AI role

AI systems are research instruments used for mathematical development, formal modeling, simulation, code generation and inspection, literature analysis, criticism and falsification attempts, and documentation.

AI assistance does not turn speculative claims into established scientific results.

## 4. Research principle

A new level of description should, where mathematically justified, recover previous descriptions as local, limiting or regime-specific cases.

Working abstraction:

`broader model → limiting regime → previous effective model`

This is a research principle to be tested, not a declared universal law.

## 5. Research discipline

Every major result should be classified as:

- SOURCE
- DEFINITION
- ASSUMPTION
- MATHEMATICAL CONSEQUENCE
- MODEL PREDICTION
- EMPIRICAL RESULT
- INTERPRETATION
- OPEN QUESTION

## 6. Reproducibility

Important computational results should include source code, parameters, input data, environment/version information, expected output, actual output, and independent reproduction where possible.

## 7. Safety

Research involving AI, biology, chemistry, weapons, or other high-risk domains requires separate misuse and safety review.

## 8. Funding

The project may later seek grants, donations, research partnerships, contracts or institutional collaboration. A legal entity should be selected only after identifying actual funding and operational requirements.

## 9. Legal form

No foreign jurisdiction is selected by this release.

Near-term strategy:

`individual researcher → documented research group → validated research program → legal entity only when needed`

## 10. Long-term vision

Build a small, transparent research laboratory capable of testing theoretical frameworks with AI and computational experiments while maintaining rigorous separation between hypothesis, mathematics and evidence.
