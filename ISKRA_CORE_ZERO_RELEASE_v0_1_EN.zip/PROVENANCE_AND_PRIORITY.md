# Provenance and Priority Record

## Purpose

Preserve provenance, chronology and authorship of the Iskra Core research program.

A timestamp is evidence that a particular data object existed no later than the relevant timestamp. It does not by itself prove scientific correctness, patent novelty, or exclusive ownership.

## Existing preservation channels

- GitHub: `https://github.com/iskra-core/Iskra-Core-`
- Zenodo research-record infrastructure
- OpenTimestamps: `https://opentimestamps.org/`

## Recommended release procedure

1. Freeze the exact release files.
2. Generate SHA-256 hashes.
3. Create a manifest of filenames and hashes.
4. Commit the release to Git.
5. Publish an immutable research record where appropriate.
6. Timestamp the release archive or manifest with OpenTimestamps.
7. Preserve the `.ots` proof beside the exact stamped file.
8. Never silently overwrite a frozen release; create a new version.

## Evidence chain

`authorship → dated source history → immutable publication → cryptographic timestamp → version history`

## Legal boundary

Copyright protects concrete expression, not an abstract scientific idea, theory, principle or method. A technical invention may require a separate patent strategy.

This record is therefore not described as a patent, state certificate of scientific discovery, or proof that the physical hypotheses are true.

## AI contribution

The human researcher remains responsible for the research record and authorship claims.

AI assistance is recorded as mathematical exploration, formalization, alternative derivations, modeling, consistency checking and literature-oriented analysis.

AI is not represented as a legal co-author or rights-holder.

## Future IP gate

Before publicly disclosing potentially patentable technical implementation, perform a separate IP/patent review. Public disclosure can affect novelty requirements.

Therefore open scientific publication and potentially protectable technical implementation are treated as separate tracks.
