# License Decision — ISKRA CORE v0.1

No open-source or permissive license is granted by this release.

Reason: the project is currently undergoing an authorship, provenance and IP assessment. Public availability of a file does not mean permission to commercially exploit an implementation.

Before selecting a license, perform an IP review of:
- theoretical text and documentation;
- source code;
- algorithms;
- technical implementations;
- experimental datasets;
- names and marks.

Scientific citation and attribution policy may be defined separately from software licensing.
