# ISKRA CORE — Low-Bureaucracy Protection Plan

## Phase 0 — now

- Freeze Zero Release v0.1.
- Keep the exact ZIP archive.
- Keep SHA-256 manifest.
- Commit the release to Git.
- Create/retain OpenTimestamps proof for the release archive or manifest.
- Publish a Zenodo record when ready.
- Do not overwrite the frozen release.

## Phase 1 — research identity

Use:

`Iskra Core — Independent Research Group`

This is a project/research identity, not a claim of incorporated legal personality.

## Phase 2 — legal entity only when useful

If funding, contracts, grants, equipment ownership or hiring require a legal person, evaluate a Russian autonomous non-profit organization (АНО) with a specialist.

Russian law expressly provides AНО for activities including science and education, and an AНО may be established by one founder. Registration is handled through the Ministry of Justice procedure.

Do not incorporate abroad merely for prestige or perceived neutrality before identifying a concrete operational need.

## Phase 3 — IP gate

Before publishing technical details that might support a patent:
- identify potentially patentable technical solutions;
- perform a prior-art search;
- consult a patent attorney;
- decide what to publish and what to keep confidential.

## Phase 4 — laboratory

Start as a computational laboratory:
- AI models;
- simulation;
- mathematical verification;
- reproducible code;
- controlled experiments;
- independent review.

Physical laboratory infrastructure comes later, if the model produces testable predictions requiring it.

## Principle

Protect the chronology first. Build bureaucracy only when it creates a concrete capability.
